const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
} = require('discord.js');
const config = require('../config');
const { getSessionByChannel, updateSession } = require('../sessions');
const { buildCitizen, cleanupWorkspace } = require('../downloader');
const { cleanupSession } = require('./tickets');

/**
 * Wysyła wiadomość z jednym krokiem kreatora.
 * Każdy krok = embed ze zdjęciem poglądowym + przyciski akcji.
 */
module.exports.sendStep = async function sendStep(channel, session, stepIndex) {
  const steps = config.steps;

  // Koniec listy -> podsumowanie
  if (stepIndex >= steps.length) {
    return sendSummary(channel, session);
  }

  const step = steps[stepIndex];
  const chosen = session.choices.has(step.id);

  const embed = new EmbedBuilder()
    .setTitle(`Krok ${stepIndex + 1}/${steps.length} — ${step.name}`)
    .setDescription(
      [
        `**${step.name}**`,
        step.description,
        '',
        chosen ? '✅ **Dodano do paczki.**' : '⬜ *Nie dodano.*',
      ].join('\n')
    )
    .setColor(chosen ? 0x57f287 : 0x5865f2)
    .setImage(step.image)
    .setFooter({ text: 'Wybierz akcję poniżej' })
    .setTimestamp();

  const row = buildStepActionRow(stepIndex, chosen);

  // Menu rozwijane z tym samym krokiem - dla wygody na kanałach, gdzie
  // użytkownik woli listę (np. gdy kroków jest więcej niż 5)
  if (steps.length > 3) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId('step_jump')
      .setPlaceholder('Przeskocz do innego kroku...')
      .addOptions(
        steps.map((s, i) => ({
          label: `${i + 1}. ${s.name}`,
          value: String(i),
          default: i === stepIndex,
          description: s.description.slice(0, 100),
        }))
      );
    row.addComponents(menu);
  }

  await channel.send({ embeds: [embed], components: [row] });
};

function buildStepActionRow(stepIndex, chosen) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`step_add:${stepIndex}`)
      .setLabel(chosen ? 'Dodano ✓ (kliknij, aby usunąć)' : 'Dodaj to')
      .setStyle(chosen ? ButtonStyle.Success : ButtonStyle.Primary)
      .setEmoji('➕'),
    new ButtonBuilder()
      .setCustomId(`step_skip:${stepIndex}`)
      .setLabel('Pomiń')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('⏭️'),
    new ButtonBuilder()
      .setCustomId(`step_remove:${stepIndex}`)
      .setLabel('Usuń z paczki')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🗑️')
  );
}

module.exports.handleStepButton = async function handleStepButton(interaction) {
  const [action, stepIndexStr] = interaction.customId.split(':');
  const stepIndex = parseInt(stepIndexStr, 10);
  const step = config.steps[stepIndex];
  const session = getSessionByChannel(interaction.channel.id);

  if (!session || !step) {
    return interaction.reply({ content: '❌ Sesja wygasła lub krok nie istnieje.', ephemeral: true });
  }

  if (interaction.user.id !== session.userId) {
    return interaction.reply({ content: '❌ To nie Twoja sesja.', ephemeral: true });
  }

  if (action === 'step_add') {
    session.choices.set(step.id, { stepIndex, addedAt: Date.now() });
    updateSession(session.channelId, session);
    await interaction.deferUpdate();
    // Odśwież bieżący krok (zaktualizowany embed + etykieta przycisku)
    await interaction.editReply({
      embeds: [makeStepEmbed(step, stepIndex, true)],
      components: [buildStepActionRow(stepIndex, true)],
    });
  } else if (action === 'step_skip') {
    session.choices.delete(step.id);
    updateSession(session.channelId, session);
    await interaction.deferUpdate();
    await sendStep(interaction.channel, session, stepIndex + 1);
  } else if (action === 'step_remove') {
    session.choices.delete(step.id);
    updateSession(session.channelId, session);
    await interaction.deferUpdate();
    await interaction.editReply({
      embeds: [makeStepEmbed(step, stepIndex, false)],
      components: [buildStepActionRow(stepIndex, false)],
    });
  }
};

function makeStepEmbed(step, stepIndex, chosen) {
  return new EmbedBuilder()
    .setTitle(`Krok ${stepIndex + 1}/${config.steps.length} — ${step.name}`)
    .setDescription([`**${step.name}**`, step.description, '', chosen ? '✅ **Dodano do paczki.**' : '⬜ *Nie dodano.*'].join('\n'))
    .setColor(chosen ? 0x57f287 : 0x5865f2)
    .setImage(step.image)
    .setFooter({ text: 'Wybierz akcję poniżej' })
    .setTimestamp();
}

/**
 * Podsumowanie wyborów + przycisk "Zakończ tworzenie".
 */
async function sendSummary(channel, session) {
  const chosenSteps = config.steps.filter((s) => session.choices.has(s.id));

  const embed = new EmbedBuilder()
    .setTitle('📋 Podsumowanie Twojego citizena')
    .setDescription(
      chosenSteps.length
        ? chosenSteps.map((s) => `✅ **${s.name}** — ${s.description}`).join('\n')
        : '*Nie wybrano żadnej modyfikacji.*'
    )
    .setColor(0xfee75c)
    .setFooter({ text: 'Kliknij „Zakończ tworzenie", aby zbudować paczkę ZIP.' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('finish_build')
      .setLabel('Zakończ tworzenie')
      .setStyle(ButtonStyle.Success)
      .setEmoji('📦'),
    new ButtonBuilder()
      .setCustomId('restart_wizard')
      .setLabel('Zacznij od nowa')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔄'),
    new ButtonBuilder()
      .setCustomId('close_session')
      .setLabel('Zamknij')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒')
  );

  await channel.send({ embeds: [embed], components: [row] });
}

module.exports.handleSummaryButton = async function handleSummaryButton(interaction) {
  const session = getSessionByChannel(interaction.channel.id);
  if (!session) {
    return interaction.reply({ content: '❌ Sesja wygasła.', ephemeral: true });
  }
  if (interaction.user.id !== session.userId) {
    return interaction.reply({ content: '❌ To nie Twoja sesja.', ephemeral: true });
  }

  if (interaction.customId === 'close_session') {
    return interaction.reply({ content: '🔒 Zamykam...', ephemeral: true }).then(async () => {
      await cleanupSession(interaction.client, session, 'Zamknięto przez użytkownika');
    });
  }

  if (interaction.customId === 'restart_wizard') {
    session.choices.clear();
    updateSession(session.channelId, session);
    await interaction.reply({ content: '🔄 Od nowa!', ephemeral: true });
    return sendStep(interaction.channel, session, 0);
  }

  if (interaction.customId === 'finish_build') {
    await interaction.deferReply();
    const chosenSteps = config.steps.filter((s) => session.choices.has(s.id));

    if (!chosenSteps.length) {
      return interaction.editReply({ content: '❌ Nie wybrano żadnej modyfikacji — nie ma czego pakować.' });
    }

    try {
      const result = await buildCitizen(session, chosenSteps);
      const link = `${config.publicUrl}/download/${result.token}`;

      const embed = new EmbedBuilder()
        .setTitle('✅ Twoja paczka jest gotowa!')
        .setDescription(
          [
            `**Pobierz paczkę:** [${result.fileName}](${link})`,
            '',
            `📦 Rozmiar: **${(result.size / 1024 / 1024).toFixed(2)} MB**`,
            `🕒 Link ważny: **24 godziny**`,
            `📁 Zawartość: ${result.fileCount} plik(ów)`,
            '',
            '**Jak zainstalować:**',
            '1. Pobierz paczkę ZIP.',
            '2. Rozpakuj do folderu `mods` w FiveM (lub wg instrukcji w paczce).',
            '3. Uruchom ponownie FiveM.',
          ].join('\n')
        )
        .setColor(0x57f287)
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      // Publikacja linku na kanale pobranych paczek
      const guild = interaction.guild;
      const downloadsChannel = guild.channels.cache.find((c) => c.name === config.channel.downloads);
      if (downloadsChannel) {
        await downloadsChannel.send({
          content: `<@${session.userId}> Twoja paczka: ${link}`,
        }).catch(() => {});
      }

      // Usuń folder roboczy po spakowaniu
      await cleanupWorkspace(result.workspace);

      // Zapytaj o zamknięcie kanału
      const closeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('close_session')
          .setLabel('Zamknij kanał')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('🔒')
      );
      await interaction.channel.send({
        content: 'Gotowe! Kliknij poniżej, aby zamknąć ten kanał.',
        components: [closeRow],
      });
    } catch (err) {
      console.error('Błąd budowania paczki:', err);
      await interaction.editReply({ content: `❌ Błąd budowania paczki: ${err.message}` });
    }
  }
};
