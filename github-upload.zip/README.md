# 🛠️ Kreator Citizenów do FiveM — Bot Discord

W pełni zautomatyzowany bot (Node.js + discord.js v14), który:

- **Auto-konfiguruje serwer** po dołączeniu: rolę `Creator`, kategorię, kanał `#stworz-citizena`, kanał `#pobrane-paczki` i panel startowy z przyciskiem.
- **Kanał #mody-optymalizacja** z kuratorowaną bazą sprawdzonych modów klienckich (embedy: nazwa, wpływ na FPS, link do strony moda) z **automatyczną weryfikacją linków** co 6 h i oznaczaniem martwych.
- **Tworzy prywatne kanały** (system ticketów) per użytkownik po kliknięciu „Zacznij tworzyć citizena".
- **Prowadzi kreatora krok po kroku**: przy każdej modyfikacji (niebo, cienie, woda, krew…) wyświetla **embed ze zdjęciem poglądowym** i przyciskami **Dodaj / Pomiń / Usuń** (+ menu rozwijane do przeskakiwania kroków).
- **Kreator skinów broni**: select menu wyboru broni (Pistol, Heavy Pistol, AP Pistol, Carbine, AK-47…), galeria skinów ze zdjęciami i przyciskami **Wróć / Wybierz / Dalej**, paczka ZIP z plikami `.ytd`/`.ydr`.
- **Backend**: pobiera pliki modyfikacji z internetu, buduje poprawną strukturę folderu `citizen` FiveM, pakuje wszystko do `.zip`.
- **Generuje link do pobrania** paczki (własny serwer HTTP) i zamyka prywatny kanał po zakończeniu.

---

## 📁 Struktura plików

```
fivem-citizen-bot/
├── package.json
├── .env                     # twój konfig (skopiuj z .env.example)
├── .env.example
├── src/
│   ├── index.js             # punkt wejścia: klient Discord + serwer HTTP
│   ├── config.js            # ⚙️ KONFIGURACJA KROKÓW KREATORA (tu dodajesz mody!)
│   ├── setup.js             # auto-konfiguracja serwera (role, kanały, panel)
│   ├── deploy-commands.js   # rejestracja komend slash
│   ├── sessions.js          # magazyn sesji kreatora (pamięć)
│   ├── downloader.js        # pobieranie plików, budowa citizen, ZIP
│   ├── http-server.js       # serwer linków do pobierania
│   ├── commands/
│   │   ├── index.js         # komendy /panel, /zamknij
│   │   ├── tickets.js       # prywatne kanały + sprzątanie sesji
│   │   ├── wizard.js        # kreator krok po kroku + podsumowanie
│   │   └── interactionCreate.js # router interakcji
│   ├── events/
│   │   ├── ready.js         # start bota + auto-konfiguracja
│   │   └── interactionCreate.js
│   ├── workspaces/          # (auto) foldery robocze
│   └── downloads/           # (auto) gotowe paczki ZIP
```

---

## 📦 Instalacja

### Wymagania
- **Node.js ≥ 18** (`node -v`)
- Na Linuxie: `unzip` (do rozpakowywania modów typu resource): `sudo apt install unzip`

### Krok 1 — Utwórz aplikację bota na Discordzie
1. Wejdź na https://discord.com/developers/applications → **New Application**.
2. Zakładka **Bot** → **Reset Token** → skopiuj token.
3. Zakładka **OAuth2 → General** → skopiuj **Client ID**.
4. Włącz **Server Members Intent** (opcjonalnie) — ten bot go nie wymaga.

### Krok 2 — Zaproś bota na serwer
Wklej w przeglądarce (podmień `CLIENT_ID`):
```
https://discord.com/oauth2/authorize?client_id=CLIENT_ID&permissions=1610883072&scope=bot%20applications.commands
```
Uprawnienia: zarządzanie kanałami, rolami, wiadomościami.

### Krok 3 — Skonfiguruj projekt
```bash
git clone <twoje-repo> fivem-citizen-bot   # lub skopiuj pliki
cd fivem-citizen-bot
npm install
cp .env.example .env
nano .env   # wklej DISCORD_TOKEN, CLIENT_ID, PUBLIC_URL
```

Przykład `.env` na VPS:
```
DISCORD_TOKEN=twoj.token.bota
CLIENT_ID=123456789012345678
HTTP_PORT=3000
PUBLIC_URL=http://123.123.123.123:3000
```

### Krok 4 — Uruchom
```bash
npm start
```
Po wejściu na Twój serwer bot sam utworzy kategorię, kanały, role i panel.

---

## ☁️ Hosting 24/7 — bot działa bez Twojego komputera

Masz 3 drogi. Dla tego bota **zalecany jest wariant B (Docker na VPS)** lub **C (Railway/Render)**.

> ⚠️ **Ważne:** darmowe plany Render/Railway **usypiają** procesy, które nie przyjmują ruchu HTTP — bot Discorda musiałby mieć „ping-keepalive", żeby nie zasnąć. Dlatego dla stabilnej pracy 24/7 wybierz płatny Starter (~5-7 USD/mies.) albo tani VPS.

---

### Wariant A — Railway (najprostszy start, ~5 USD/mies.)

Repo ma gotowy plik `railway.json`:

1. Wrzuć projekt na **GitHub** (bez pliku `.env` — jest w `.gitignore`).
2. Wejdź na [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo**.
3. Railway sam wykryje `Dockerfile` i zbuduje bota.
4. W zakładce **Variables** dodaj:
   - `DISCORD_TOKEN`, `CLIENT_ID`,
   - `HTTP_PORT=3000`,
   - `PUBLIC_URL` — Railway → zakładka **Settings → Networking → Generate Domain**; wklej wygenerowany adres (np. `https://citizen-bot-production.up.railway.app`).
5. Po deploju bot wstaje i sam konfiguruje serwer Discord.

### Wariant B — Docker na własnym VPS (pełna kontrola, ~4-6 USD/mies.)

Repo ma gotowy `Dockerfile` i `docker-compose.yml` (działa na Hetzner, OVH, Contabo, DigitalOcean itd.):

1. Zamów najtańszy VPS z Ubuntu 22.04/24.04.
2. Zainstaluj Dockera:
   ```bash
   curl -fsSL https://get.docker.com | sh
   ```
3. Skopiuj projekt na serwer (np. przez `git clone` lub SFTP) i utwórz `.env`:
   ```bash
   cp .env.example .env
   nano .env   # DISCORD_TOKEN, CLIENT_ID, PUBLIC_URL=http://IP_VPS:3000
   ```
4. Uruchom:
   ```bash
   docker compose up -d --build
   ```
5. Sprawdź:
   ```bash
   docker compose logs -f          # logi bota
   curl http://IP_VPS:3000/health  # powinno zwrócić: ok
   ```

Kontener ma `restart: unless-stopped` — po restarcie VPS bota sam wstaje. Otwórz port: `sudo ufw allow 3000/tcp`.

### Wariant C — Render (deploy z GitHub, ~7 USD/mies.)

Repo ma gotowy `render.yaml` (Blueprint):

1. Wrzuć projekt na GitHub.
2. [render.com](https://render.com) → **New → Blueprint** → wybierz repo.
3. W panelu uzupełnij `DISCORD_TOKEN`, `CLIENT_ID`, `PUBLIC_URL` (Render sam poda domenę `*.onrender.com`).
4. Render buduje z `Dockerfile`, montuje dysk 1 GB na wygenerowane paczki i odpytuje `/health`.

### Czego NIE używać

- **Darmowych planów** Render/Railway/Fly.io dla procesu długoterminowego — kontenery zasypiają i bot wypada z Discorda.
- **Glitch/Replit free** — limity czasu procesu (projekt usypiany po kilku minutach bez ruchu).

## 🚀 Uruchomienie na VPS bez Dockera (alternatywa)

### Opcja A — PM2 (najprostsze)
```bash
sudo npm install -g pm2
pm2 start src/index.js --name citizen-bot
pm2 save
pm2 startup   # wykonaj polecenie, które wypisze
```

### Opcja B — systemd (czystsze)
Utwórz `/etc/systemd/system/citizen-bot.service`:
```ini
[Unit]
Description=FiveM Citizen Creator Bot
After=network.target

[Service]
Type=simple
User=twojuser
WorkingDirectory=/home/twojuser/fivem-citizen-bot
ExecStart=/usr/bin/node src/index.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now citizen-bot
sudo systemctl status citizen-bot
```

### Firewall — otwórz port HTTP
```bash
sudo ufw allow 3000/tcp
```

---

## 🖼️ Własne grafiki i pliki modów

**Cała konfiguracja kreatora jest w `src/config.js`** w tablicy `steps`.

Dla każdego kroku podajesz:
- `image` — URL zdjęcia poglądowego (hostuj np. na imgur; Discord wymaga publicznego URL-a),
- `fileUrl` — link do pliku moda do pobrania (bezpośredni link!),
- `fileName` — nazwa pliku w paczce,
- `target` — ścieżka wewnątrz struktury `citizen` FiveM,
- `mode`:
  - `file` — pobierz pojedynczy plik i wstaw pod `fileName`,
  - `resource` — pobierz ZIP z modem i rozpakuj do `target`.

Aby dodać nowy krok, dopisz obiekt do tablicy `steps` — reszta dzieje się automatycznie.

### Mody optymalizacyjne (#mody-optymalizacja)

Tablica `optimizationMods` w `src/config.js`. Bot **nie przeszukuje internetu sam** —
linki wstawiasz po ręcznej weryfikacji (GitHub, gta5-mods.com, forum.cfx.re),
a bot **automatycznie sprawdza co 6 h**, czy linki żyją (HEAD request) i oznacza
martwe na kanale. Linkuj do **strony moda**, nie do pliku — taki URL nie wygasa.

### Skiny broni

Tablica `weapons` w `src/config.js`: lista broni, a dla każdej lista skinów
(`image` — podgląd, `fileUrl` — plik `.ytd`/`.ydr`, `target` — ścieżka w strukturze
citizen). Dodanie nowej broni lub skina = dopisanie obiektu.

---

## 🔒 Bezpieczeństwo

- Pobieranie plików jest limitowane (`maxDownloadBytes`, domyślnie 200 MB na plik).
- Paczki ZIP wygasają po 24 h i są automatycznie usuwane.
- Linki do pobrania zawierają losowy 32-znakowy token.
- Sesje kreatora wygasają po 2 h bezczynności.
- Komenda `/panel` wymaga uprawnień administratora.

---

## ❓ FAQ

**Bot nie tworzy kanałów po dołączeniu?**
Sprawdź, czy ma rolę **wyżej** niż role, które ma nadawać, i uprawnienie `Manage Roles` / `Manage Channels`.

**Zdjęcia nie wyświetlają się w embedach?**
Discord wymaga publicznych, działających URL-i do obrazków. Upewnij się, że linki w `config.js` otwierają się w incognito.

**Jak zmienić nazwy kanałów/ról?**
Sekcja `role`, `category` i `channel` w `src/config.js`.
