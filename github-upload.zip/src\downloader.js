const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { pipeline } = require('stream/promises');
const archiver = require('archiver');
const config = require('./config');

const WORKSPACES_ROOT = path.join(process.cwd(), 'workspaces');
const DOWNLOADS_ROOT = path.join(process.cwd(), 'downloads');

// Mapa token -> { filePath, fileName, size, fileCount, workspace, createdAt }
const pendingDownloads = new Map();

function ensureDirs() {
  fs.mkdirSync(WORKSPACES_ROOT, { recursive: true });
  fs.mkdirSync(DOWNLOADS_ROOT, { recursive: true });
}

/**
 * Pobiera plik z URL do wskazanej ścieżki docelowej (strumieniowo, z limitem rozmiaru).
 */
async function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const proto = url.startsWith('https') ? https : http;
    const request = (targetUrl, redirectsLeft) => {
      proto
        .get(targetUrl, { headers: { 'User-Agent': 'FiveMCitizenBot/1.0' } }, (res) => {
          // Obsługa przekierowań (np. GitHub releases)
          if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
            res.resume();
            if (redirectsLeft <= 0) return reject(new Error('Za dużo przekierowań'));
            const next = new URL(res.headers.location, targetUrl).toString();
            return request(next, redirectsLeft - 1);
          }
          if (res.statusCode !== 200) {
            res.resume();
            return reject(new Error(`HTTP ${res.statusCode} przy pobieraniu ${targetUrl}`));
          }

          const out = fs.createWriteStream(destPath);
          let received = 0;
          let aborted = false;

          res.on('data', (chunk) => {
            received += chunk.length;
            if (received > config.limits.maxDownloadBytes && !aborted) {
              aborted = true;
              res.destroy();
              out.destroy();
              fs.rmSync(destPath, { force: true });
              reject(new Error('Plik przekracza limit rozmiaru'));
            }
          });

          pipeline(res, out)
            .then(() => {
              if (!aborted) resolve(destPath);
            })
            .catch((err) => {
              if (!aborted) reject(err);
            });
        })
        .on('error', reject);
    };
    request(url, 5);
  });
}

/**
 * Buduje drzewo folderów wewnątrz workspace.
 */
function mkdirp(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

/**
 * Główna funkcja: buduje strukturę citizen, pobiera wybrane pliki, pakuje do ZIP.
 */
module.exports.buildCitizen = async function buildCitizen(session, chosenSteps) {
  ensureDirs();
  const token = crypto.randomBytes(16).toString('hex');
  const workspace = path.join(WORKSPACES_ROOT, `${session.userId}-${Date.now()}`);
  mkdirp(workspace);

  const zipPath = path.join(DOWNLOADS_ROOT, `${token}.zip`);

  // 1. Pobranie plików i zbudowanie struktury folderów
  for (const step of chosenSteps) {
    const targetDir = path.join(workspace, step.target);
    mkdirp(targetDir);

    const destFile = path.join(targetDir, step.fileName);

    if (step.mode === 'file') {
      console.log(`⬇️  Pobieram: ${step.fileUrl}`);
      await downloadFile(step.fileUrl, destFile);
      console.log(`✅ Zapisano: ${destFile}`);
    } else if (step.mode === 'resource') {
      // Zip z modem - pobierz i rozpakuj
      const tmpZip = path.join(WORKSPACES_ROOT, `tmp-${crypto.randomBytes(8).toString('hex')}.zip`);
      await downloadFile(step.fileUrl, tmpZip);
      const { execSync } = require('child_process');
      if (process.platform === 'win32') {
        execSync(`powershell -Command "Expand-Archive -Path '${tmpZip}' -DestinationPath '${targetDir}' -Force"`);
      } else {
        execSync(`unzip -o "${tmpZip}" -d "${targetDir}"`);
      }
      fs.unlinkSync(tmpZip);
      console.log(`✅ Rozpakowano resource: ${step.fileUrl} -> ${targetDir}`);
    }
  }

  // 2. Instrukcja instalacji w paczce
  fs.writeFileSync(
    path.join(workspace, 'INSTRUKCJA.txt'),
    [
      '=== TWOJA PACZKA CITIZEN ===',
      `Wygenerowano: ${new Date().toLocaleString('pl-PL')}`,
      '',
      'Wybrane modyfikacje:',
      ...chosenSteps.map((s) => ` - ${s.name}: ${s.description}`),
      '',
      'Instalacja:',
      '1. Rozpakuj pliki do folderu FiveM (zachowaj strukturę folderów).',
      '2. Uruchom ponownie FiveM.',
      '',
      'Struktura folderów w tej paczce odpowiada strukturze folderu citizen w FiveM.',
    ].join('\n'),
    'utf-8'
  );

  // 3. Pakowanie do ZIP
  const size = await zipDirectory(workspace, zipPath);

  // 4. Zlicz pliki
  let fileCount = 0;
  (function countFiles(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.isDirectory()) countFiles(path.join(dir, entry.name));
      else fileCount++;
    }
  })(workspace);

  const fileName = `citizen-${session.userId}-${Date.now()}.zip`;

  pendingDownloads.set(token, {
    filePath: zipPath,
    fileName,
    size,
    fileCount,
    workspace,
    createdAt: Date.now(),
  });

  return { token, fileName, size, fileCount, workspace };
};

/**
 * Pakuje folder do ZIP-a.
 */
function zipDirectory(sourceDir, outPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve(archive.pointer()));
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize();
  });
}

/**
 * Zwraca dane pobrania dla tokenu (lub null).
 */
module.exports.getDownload = function getDownload(token) {
  return pendingDownloads.get(token);
};

/**
 * Usuwa folder roboczy po spakowaniu.
 */
module.exports.cleanupWorkspace = async function cleanupWorkspace(workspace) {
  if (workspace && workspace.startsWith(WORKSPACES_ROOT)) {
    fs.rmSync(workspace, { recursive: true, force: true });
  }
};

// Sprzątanie starych paczek ZIP
setInterval(() => {
  ensureDirs();
  const now = Date.now();
  for (const [token, d] of pendingDownloads) {
    if (now - d.createdAt > config.limits.downloadTtlMs) {
      pendingDownloads.delete(token);
      fs.rmSync(d.filePath, { force: true });
      console.log(`🧹 Usunięto wygasłą paczkę ${d.fileName}`);
    }
  }
}, 30 * 60 * 1000).unref();
