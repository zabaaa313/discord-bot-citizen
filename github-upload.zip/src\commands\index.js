const { sendPanel } = require('../setup');
const { handleCloseSession } = require('./tickets');

module.exports.panel = {
  async execute(interaction) {
    await interaction.reply({ content: 'Wysyłam panel...', ephemeral: true });
    await sendPanel(interaction.channel);
  },
};

module.exports.zamknij = {
  async execute(interaction) {
    await handleCloseSession(interaction, 'Zamknięto komendą /zamknij');
  },
};
