/**
 * Prosty magazyn sesji w pamięci.
 * Klucz: channelId kanału prywatnego -> obiekt sesji.
 * Sesja: { userId, guildId, channelId, choices: Map<stepId, {stepIndex, addedAt}>, createdAt }
 */
const config = require('./config');

const sessions = new Map();

module.exports.createSession = function createSession({ userId, guildId, channelId }) {
  const session = {
    userId,
    guildId,
    channelId,
    choices: new Map(),
    createdAt: Date.now(),
    lastActivity: Date.now(),
  };
  sessions.set(channelId, session);
  return session;
};

module.exports.getSessionByChannel = function getSessionByChannel(channelId) {
  return sessions.get(channelId);
};

module.exports.getSessionByUser = function getSessionByUser(userId, guildId) {
  for (const s of sessions.values()) {
    if (s.userId === userId && s.guildId === guildId) return s;
  }
  return null;
};

module.exports.updateSession = function updateSession(channelId, session) {
  session.lastActivity = Date.now();
  sessions.set(channelId, session);
};

module.exports.deleteSession = function deleteSession(channelId) {
  sessions.delete(channelId);
};

// Wątek sprzątający wygasłe sesje (np. gdy użytkownik zniknął, a kanał nie został usunięty)
setInterval(() => {
  const now = Date.now();
  for (const [channelId, s] of sessions) {
    if (now - s.lastActivity > config.limits.sessionTtlMs) {
      sessions.delete(channelId);
      console.log(`🧹 Wygasła sesja na kanale ${channelId}`);
    }
  }
}, 10 * 60 * 1000).unref();
