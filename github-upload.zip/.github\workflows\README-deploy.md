# 🚀 Automatyczny deploy na VPS (GitHub Actions)

Po każdym pushu na `main` workflow:

1. **Smoke-test** — sprawdza składnię plików `src/` i robi czysty `npm ci`.
2. **rsync** — wgrywa pliki na VPS (bez `node_modules`, `.env`, `downloads`, `workspaces` — te zostają na serwerze).
3. **Rebuild** — `docker compose up -d --build` na serwerze (przebudowa kontenera z nowym kodem).
4. **Healthcheck** — czeka do 60 s na odpowiedź `http://localhost:3000/health`; przy błędzie wyświetla logi kontenera.

Workflow plik: [`.github/workflows/deploy-vps.yml`](./deploy-vps.yml)

---

## 📋 Konfiguracja — krok po kroku

### Krok 1. Wygeneruj parę kluczy SSH dedykowaną deployowi

Na Twoim komputerze:

```bash
ssh-keygen -t ed25519 -C "github-actions-deploy" -f deploy_key -N ""
```

Powstaną dwa pliki: `deploy_key` (prywatny) i `deploy_key.pub` (publiczny).

### Krok 2. Dodaj klucz publiczny na VPS

```bash
ssh-copy-id -i deploy_key.pub twojuser@IP_VPS
# lub ręcznie: dopisz zawartość deploy_key.pub do ~/.ssh/authorized_keys na VPS
```

Upewnij się, że użytkownik VPS ma uprawnienia do `docker compose` (należy do grupy `docker`):

```bash
sudo usermod -aG docker twojuser
```

### Krok 3. Dodaj sekrety w GitHubie

Repozytorium na GitHubie → **Settings → Secrets and variables → Actions → New repository secret**:

| Nazwa sekretu | Wartość | Przykład |
|---|---|---|
| `VPS_SSH_KEY` | **cała** zawartość pliku `deploy_key` (prywatny, łącznie z `-----BEGIN...-----` i `-----END...-----`) | `-----BEGIN OPENSSH PRIVATE KEY-----...` |
| `VPS_HOST` | adres IP lub domena VPS | `203.0.113.10` |
| `VPS_USER` | użytkownik SSH | `deploy` |
| `VPS_PATH` | ścieżka projektu na VPS | `/home/deploy/fivem-citizen-bot` |

### Krok 4. Pierwsze uruchomienie

1. Upewnij się, że na VPS jest już sklonowany projekt i działający `.env` (workflow **nie nadpisuje** `.env`).
2. Commit i push na `main` — albo wejdź w **Actions → Deploy na VPS → Run workflow** (ręczne uruchomienie).
3. Obserwuj przebieg w zakładce **Actions** — każdy krok pokazuje logi.

---

## 🧯 Rozwiązywanie problemów

| Problem | Rozwiązanie |
|---|---|
| `Permission denied (publickey)` | Sekret `VPS_SSH_KEY` nie zawiera pełnego klucza prywatnego (z nagłówkiem i stopką) lub klucz publiczny nie jest w `authorized_keys` na VPS. |
| `permission denied ... docker.sock` | Użytkownik VPS nie jest w grupie `docker` — `sudo usermod -aG docker USER`, potem zaloguj się ponownie. |
| Healthcheck fails | Bot się nie uruchomił — zajrzyj do logów na końcu kroku; najczęściej błędny `DISCORD_TOKEN` w `.env` na VPS. |
| Port SSH inny niż 22 | Dodaj w krokach SSH pole `port: 2222` (lub swój) i `REMOTE_PORT` w ssh-deploy. |
| Chcesz deployować z innego brancha | Zmień `branches: [main]` w `on: push` na swoją gałąź. |
