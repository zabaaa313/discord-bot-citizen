const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const config = require('./config');

/**
 * Automatyczna konfiguracja serwera po dołączeniu bota:
 * - rola "Creator"
 * - kategoria "FIVEM CITIZEN CREATOR"
 * - kanał główny #stworz-citizena
 * - kanał #pobrane-paczki
 * - panel startowy z przyciskiem
 */
module.exports.setupGuild = async function setupGuild(guild) {
  console.log(`⚙️  Konfiguracja serwera: ${guild.name} (${guild.id})`);

  // 1. Rola Creator
  let creatorRole = guild.roles.cache.find((r) => r.name === config.role.creator);
  if (!creatorRole) {
    creatorRole = await guild.roles.create({
      name: config.role.creator,
      color: 0x5865f2,
      reason: 'Auto-konfiguracja: rola kreatora citizena',
    });
  }

  // 2. Rola "w trakcie tworzenia" (tymczasowa)
  let buildingRole = guild.roles.cache.find((r) => r.name === config.role.building);
  if (!buildingRole) {
    buildingRole = await guild.roles.create({
      name: config.role.building,
      color: 0x57f287,
      reason: 'Auto-konfiguracja: rola tymczasowa podczas tworzenia',
    });
  }

  // 3. Kategoria
  let category = guild.channels.cache.find(
    (c) => c.name === config.category.main && c.type === ChannelType.GuildCategory
  );
  if (!category) {
    category = await guild.channels.create({
      name: config.category.main,
      type: ChannelType.GuildCategory,
    });
  }

  // 4. Kanał główny
  let mainChannel = guild.channels.cache.find(
    (c) => c.name === config.channel.main && c.parentId === category.id
  );
  if (!mainChannel) {
    mainChannel = await guild.channels.create({
      name: config.channel.main,
      type: ChannelType.GuildText,
      parent: category.id,
      topic: 'Kliknij przycisk poniżej, aby rozpocząć tworzenie własnego citizena.',
    });
  }

  // 5. Kanał z pobranymi paczkami
  let downloadsChannel = guild.channels.cache.find(
    (c) => c.name === config.channel.downloads && c.parentId === category.id
  );
  if (!downloadsChannel) {
    downloadsChannel = await guild.channels.create({
      name: config.channel.downloads,
      type: ChannelType.GuildText,
      parent: category.id,
      topic: 'Bot publikuje tutaj linki do pobrania gotowych paczek citizena.',
    });
  }

  // 6. Kanał z modami optymalizacyjnymi
  const { setupModsChannel } = require('./mods-channel');
  await setupModsChannel(guild);

  // 7. Panel startowy
  await sendPanel(mainChannel, creatorRole);
  console.log(`✅ Konfiguracja serwera ${guild.name} zakończona.`);
};

module.exports.sendPanel = async function sendPanel(channel) {
  const embed = new EmbedBuilder()
    .setTitle('🛠️ Kreator Citizenów — FiveM')
    .setDescription(
      [
        'Kliknij **„Zacznij tworzyć citizena"** poniżej, aby uruchomić kreatora.',
        '',
        'Bot stworzy prywatny kanał, na którym krok po kroku wybierzesz modyfikacje',
        '(niebo, cienie, woda, krew itp.), a następnie automatycznie pobierze pliki',
        'i zbuduje gotową paczkę `.zip` do wgrania do FiveM.',
      ].join('\n')
    )
    .setColor(0x5865f2)
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('create_citizen')
      .setLabel('Zacznij tworzyć citizena')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🛠️')
  );

  await channel.send({ embeds: [embed], components: [row] });
};
