const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
} = require('discord.js');
const config = require('../config');
const { getSessionByChannel, updateSession } = require('../sessions');
const { buildCitizen } = require('../downloader');

/**
 * Wysyła menu wyboru broni (krok 0 kreatora skinów).
 */
module.exports.sendWeaponSelect = async function sendWeaponSelect(channel, session) {
  const embed = new EmbedBuilder()
    .setTitle('🔫 Kreator skinów broni — wybierz broń')
    .setDescription(
      [
        'Z listy poniżej wybierz broń, dla której chcesz dobrać skin.',
        'Po wyborze zobaczysz dostępne skiny ze zdjęciami poglądowymi.',
        '',
        '💡 Możesz zmodyfikować wiele broni — po prostu wracaj do tego menu.',
        'Na końcu bot spakuje pliki `.ytd`/`.ydr` do paczki ZIP.',
      ].join('\n')
    )
    .setColor(0xe67e22)
    .setTimestamp();

  const menu = new StringSelectMenuBuilder()
    .setCustomId('ws_weapon_select')
    .setPlaceholder('Wybierz broń...')
    .addOptions(
      config.weapons.map((w) => ({
        label: w.name,
        value: w.id,
        description: `${w.skins.length} skin(ów) dostępnych`,
      }))
    );

  const doneRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ws_finish')
      .setLabel('Zakończ i zbuduj paczkę')
      .setStyle(ButtonStyle.Success)
      .setEmoji('📦'),
    new ButtonBuilder()
      .setCustomId('ws_cancel')
      .setLabel('Anuluj kreatora skinów')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('✖️')
  );

  await channel.send({
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(menu), doneRow],
  });
};

/**
 * Wyświetla skiny wybranej broni (krok 1).
 */
module.exports.sendSkinGallery = async function sendSkinGallery(channel, session, weapon) {
  session.weaponSkins = session.weaponSkins || {}; // weaponId -> skinId
  const chosenSkinId = session.weaponSkins[weapon.id];
  const chosenSkin = weapon.skins.find((s) => s.id === chosenSkinId);

  const displayIndex = chosenSkin ? weapon.skins.findIndex((s) => s.id === chosenSkinId) : 0;
  const skin = weapon.skins[displayIndex];

  const embed = new EmbedBuilder()
    .setTitle(`🔫 ${weapon.name} — ${skin.name}`)
    .setDescription(
      [
        `**${skin.name}** — ${skin.description}`,
        '',
        chosenSkin ? '✅ **Ten skin jest w Twojej paczce.**' : '⬜ *Nie wybrano.*',
      ].join('\n')
    )
    .setColor(0xe67e22)
    .setImage(skin.image)
    .setTimestamp();

  const menu = new StringSelectMenuBuilder()
    .setCustomId(`ws_skin_select:${weapon.id}`)
    .setPlaceholder('Wybierz skin...')
    .addOptions(
      weapon.skins.map((s) => ({
        label: s.name,
        value: s.id,
        description: s.description.slice(0, 100),
        default: s.id === chosenSkinId,
      }))
    );

  await channel.send({
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(menu),
      buildSkinNavRow(weapon, displayIndex, chosenSkinId),
      buildFinishRow(),
    ],
  });
};

function buildSkinNavRow(weapon, skinIndex, chosenSkinId) {
  const skin = weapon.skins[skinIndex];
  const isChosen = chosenSkinId === skin.id;
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ws_prev:${weapon.id}:${skinIndex}`)
      .setLabel('◀ Wróć')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`ws_choose:${weapon.id}:${skinIndex}`)
      .setLabel(isChosen ? 'Wybrano ✓' : 'Wybierz ten skin')
      .setStyle(isChosen ? ButtonStyle.Success : ButtonStyle.Primary)
      .setEmoji('✅'),
    new ButtonBuilder()
      .setCustomId(`ws_next:${weapon.id}:${skinIndex}`)
      .setLabel('Dalej ▶')
      .setStyle(ButtonStyle.Secondary)
  );
}

function buildFinishRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ws_back_to_weapons')
      .setLabel('← Inna broń')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔫'),
    new ButtonBuilder()
      .setCustomId('ws_finish')
      .setLabel('Zakończ i zbuduj paczkę')
      .setStyle(ButtonStyle.Success)
      .setEmoji('📦')
  );
}

function buildSkinEmbed(weapon, skinIndex, chosenSkinId, okColor) {
  const skin = weapon.skins[skinIndex];
  const isChosen = chosenSkinId === skin.id;
  return new EmbedBuilder()
    .setTitle(`🔫 ${weapon.name} — ${skin.name}`)
    .setDescription(
      [
        `**${skin.name}** — ${skin.description}`,
        '',
        isChosen ? '✅ **Ten skin jest w Twojej paczce.**' : '⬜ *Nie wybrano.*',
      ].join('\n')
    )
    .setColor(okColor && isChosen ? 0x57f287 : 0xe67e22)
    .setImage(skin.image)
    .setTimestamp();
}

/**
 * Obsługa wszystkich interakcji kreatora skinów.
 */
module.exports.handleWeaponSkinsInteraction = async function handleWeaponSkinsInteraction(interaction) {
  const session = getSessionByChannel(interaction.channel.id);
  if (!session) {
    return interaction.reply({ content: '❌ Sesja wygasła — uruchom kreator na nowo.', ephemeral: true });
  }
  if (interaction.user.id !== session.userId) {
    return interaction.reply({ content: '❌ To nie Twoja sesja.', ephemeral: true });
  }

  session.weaponSkins = session.weaponSkins || {};

  // --- Wybór broni ---
  if (interaction.isStringSelectMenu() && interaction.customId === 'ws_weapon_select') {
    const weapon = config.weapons.find((w) => w.id === interaction.values[0]);
    if (!weapon) return interaction.reply({ content: '❌ Nie znaleziono broni.', ephemeral: true });
    await interaction.deferUpdate();
    return sendSkinGallery(interaction.channel, session, weapon);
  }

  // --- Wybór skina z menu (natychmiastowy wybór) ---
  if (interaction.isStringSelectMenu() && interaction.customId.startsWith('ws_skin_select:')) {
    const weaponId = interaction.customId.split(':')[1];
    const weapon = config.weapons.find((w) => w.id === weaponId);
    const skin = weapon?.skins.find((s) => s.id === interaction.values[0]);
    if (!weapon || !skin) return interaction.reply({ content: '❌ Nie znaleziono skina.', ephemeral: true });

    session.weaponSkins[weapon.id] = skin.id;
    updateSession(session.channelId, session);
    await interaction.deferUpdate();

    const idx = weapon.skins.findIndex((s) => s.id === skin.id);
    return interaction.editReply({
      embeds: [buildSkinEmbed(weapon, idx, skin.id, true)],
      components: [buildSkinNavRow(weapon, idx, skin.id), buildFinishRow()],
    });
  }

  // --- Nawigacja po skinach ---
  if (interaction.isButton()) {
    const parts = interaction.customId.split(':');
    const action = parts[0];

    if (action === 'ws_prev' || action === 'ws_next') {
      const weapon = config.weapons.find((w) => w.id === parts[1]);
      const idx = parseInt(parts[2], 10);
      const nextIdx = action === 'ws_next'
        ? (idx + 1) % weapon.skins.length
        : (idx - 1 + weapon.skins.length) % weapon.skins.length;
      await interaction.deferUpdate();
      const chosenSkinId = session.weaponSkins[weapon.id];
      return interaction.editReply({
        embeds: [buildSkinEmbed(weapon, nextIdx, chosenSkinId)],
        components: [buildSkinNavRow(weapon, nextIdx, chosenSkinId), buildFinishRow()],
      });
    }

    if (action === 'ws_choose') {
      const weapon = config.weapons.find((w) => w.id === parts[1]);
      const idx = parseInt(parts[2], 10);
      const skin = weapon.skins[idx];

      // Toggle: klik ponownie odznacza skin
      if (session.weaponSkins[weapon.id] === skin.id) {
        delete session.weaponSkins[weapon.id];
      } else {
        session.weaponSkins[weapon.id] = skin.id;
      }
      updateSession(session.channelId, session);

      await interaction.deferUpdate();
      return interaction.editReply({
        embeds: [buildSkinEmbed(weapon, idx, session.weaponSkins[weapon.id], true)],
        components: [buildSkinNavRow(weapon, idx, session.weaponSkins[weapon.id]), buildFinishRow()],
      });
    }

    if (interaction.customId === 'ws_back_to_weapons') {
      await interaction.deferUpdate();
      return sendWeaponSelect(interaction.channel, session);
    }

    if (interaction.customId === 'ws_cancel') {
      session.weaponSkins = {};
      updateSession(session.channelId, session);
      return interaction.reply({ content: '✖️ Kreator skinów anulowany.', ephemeral: true });
    }

    if (interaction.customId === 'ws_finish') {
      const chosenCount = Object.keys(session.weaponSkins).length;
      if (!chosenCount) {
        return interaction.reply({ content: '❌ Nie wybrano żadnego skina.', ephemeral: true });
      }

      await interaction.deferReply();

      // Zamień wybory skinów na "kroki" kompatybilne z buildCitizen
      const chosenSteps = Object.entries(session.weaponSkins).map(([weaponId, skinId]) => {
        const weapon = config.weapons.find((w) => w.id === weaponId);
        const skin = weapon.skins.find((s) => s.id === skinId);
        return {
          id: skin.id,
          name: `${weapon.name} — ${skin.name}`,
          description: skin.description,
          mode: skin.mode,
          fileUrl: skin.fileUrl,
          fileName: skin.fileName,
          target: skin.target,
        };
      });

      try {
        const result = await buildCitizen(session, chosenSteps);
        const link = `${config.publicUrl}/download/${result.token}`;

        const embed = new EmbedBuilder()
          .setTitle('✅ Paczka skinów broni gotowa!')
          .setDescription(
            [
              `**Pobierz:** [${result.fileName}](${link})`,
              '',
              `📦 Rozmiar: **${(result.size / 1024 / 1024).toFixed(2)} MB**`,
              `🕒 Link ważny: **24 godziny**`,
              '',
              '**Instalacja:** rozpakuj i podmień pliki zgodnie ze strukturą folderów w paczce.',
            ].join('\n')
          )
          .setColor(0x57f287)
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
      } catch (err) {
        console.error('Błąd budowania paczki skinów:', err);
        await interaction.editReply({ content: `❌ Błąd: ${err.message}` });
      }
    }
  }
};
