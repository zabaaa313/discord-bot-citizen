const { Events } = require('discord.js');
const { getSessionByChannel } = require('../sessions');
const { handleStepButton, handleSummaryButton } = require('./wizard');

module.exports.onInteractionCreate = async function onInteractionCreate(client, interaction) {
  try {
    // === Slash commands ===
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (command) await command.execute(interaction);
      return;
    }

    // === Buttons ===
    if (interaction.isButton()) {
      const id = interaction.customId;

      if (id === 'create_citizen') {
        const { handleCreateCitizen } = require('./tickets');
        return handleCreateCitizen(interaction);
      }

      if (id === 'create_weapon_skins') {
        const { handleCreateWeaponSkins } = require('./tickets');
        return handleCreateWeaponSkins(interaction);
      }

      if (id.startsWith('ws_')) {
        const { handleWeaponSkinsInteraction } = require('./weapon-skins');
        return handleWeaponSkinsInteraction(interaction);
      }

      if (id.startsWith('step_add:') || id.startsWith('step_skip:') || id.startsWith('step_remove:')) {
        return handleStepButton(interaction);
      }

      if (id === 'finish_build' || id === 'restart_wizard' || id === 'close_session') {
        return handleSummaryButton(interaction);
      }
    }

    // === Select menus ===
    if (interaction.isStringSelectMenu() && interaction.customId === 'ws_weapon_select') {
      const { handleWeaponSkinsInteraction } = require('./weapon-skins');
      return handleWeaponSkinsInteraction(interaction);
    }

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('ws_skin_select:')) {
      const { handleWeaponSkinsInteraction } = require('./weapon-skins');
      return handleWeaponSkinsInteraction(interaction);
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'step_jump') {
      const session = getSessionByChannel(interaction.channel.id);
      if (!session) return interaction.reply({ content: '❌ Sesja wygasła.', ephemeral: true });
      if (interaction.user.id !== session.userId) {
        return interaction.reply({ content: '❌ To nie Twoja sesja.', ephemeral: true });
      }
      const { sendStep } = require('./wizard');
      const idx = parseInt(interaction.values[0], 10);
      await interaction.deferUpdate();
      return sendStep(interaction.channel, session, idx);
    }
  } catch (err) {
    console.error('Błąd obsługi interakcji:', err);
    const payload = { content: '❌ Wystąpił błąd.', ephemeral: true };
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(payload).catch(() => {});
    } else {
      await interaction.reply(payload).catch(() => {});
    }
  }
};
