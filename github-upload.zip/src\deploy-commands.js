const { REST, Routes } = require('discord.js');
const config = require('./config');

const commands = [
  {
    name: 'panel',
    description: 'Wysyła panel kreatora citizena na bieżący kanał',
    default_member_permissions: '0', // tylko administratorzy
  },
  {
    name: 'zamknij',
    description: 'Zamyka sesję kreatora na tym kanale',
  },
];

module.exports.registerCommands = async function registerCommands(client) {
  const rest = new REST({ version: '10' }).setToken(config.token);

  try {
    await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
    console.log('✅ Zarejestrowano komendy slash.');
  } catch (err) {
    console.error('❌ Nie udało się zarejestrować komend:', err);
  }

  const { panel, zamknij } = require('./commands');

  client.commands.set('panel', panel);
  client.commands.set('zamknij', zamknij);
};
