const http = require('http');
const fs = require('fs');
const config = require('./config');
const { getDownload } = require('./downloader');

module.exports.startHttpServer = function startHttpServer() {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);

    // GET /download/:token
    const match = url.pathname.match(/^\/download\/([a-f0-9]+)$/);
    if (match) {
      const download = getDownload(match[1]);
      if (!download) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('404: Paczka nie istnieje lub wygasła.');
      }

      res.writeHead(200, {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${download.fileName}"`,
        'Content-Length': download.size,
      });
      fs.createReadStream(download.filePath).pipe(res);
      return;
    }

    // GET /health
    if (url.pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      return res.end('ok');
    }

    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('404');
  });

  server.listen(config.httpPort, () => {
    console.log(`🌐 Serwer HTTP nasłuchuje na porcie ${config.httpPort} (paczki: ${config.publicUrl}/download/<token>)`);
  });
};
