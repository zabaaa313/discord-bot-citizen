const {
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const https = require('https');
const http = require('http');
const config = require('./config');

// cache wyników weryfikacji: url -> { ok, sizeMB, checkedAt, status }
const linkHealth = new Map();

/**
 * Sprawdza URL metodą HEAD (fallback na GET z abortem) - czy odpowiada 2xx/3xx.
 * Zwraca { ok, status, sizeMB }.
 */
function checkUrl(url, redirectsLeft = 5) {
  return new Promise((resolve) => {
    const proto = url.startsWith('https') ? https : http;
    const req = proto.request(
      url,
      { method: 'HEAD', headers: { 'User-Agent': 'FiveMCitizenBot/1.0' }, timeout: 10000 },
      (res) => {
        res.resume();
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirectsLeft > 0) {
          const next = new URL(res.headers.location, url).toString();
          return resolve(checkUrl(next, redirectsLeft - 1));
        }
        const len = parseInt(res.headers['content-length'] || '0', 10);
        resolve({ ok: res.statusCode >= 200 && res.statusCode < 400, status: res.statusCode, sizeMB: len / 1024 / 1024 });
      }
    );
    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, status: 0, sizeMB: 0 });
    });
    req.on('error', () => resolve({ ok: false, status: 0, sizeMB: 0 }));
    req.end();
  });
}

/**
 * Weryfikuje wszystkie mody z bazy i aktualizuje cache.
 */
async function verifyAllMods() {
  for (const mod of config.optimizationMods) {
    // Weryfikujemy pageUrl (strona moda) - to na nią prowadzi przycisk.
    const result = await checkUrl(mod.pageUrl || mod.url);
    linkHealth.set(mod.id, { ...result, checkedAt: Date.now() });
    if (!result.ok) {
      console.warn(`⚠️  Mod "${mod.name}" - link nieosiągalny (HTTP ${result.status}): ${mod.pageUrl || mod.url}`);
    }
  }
}

/**
 * Tworzy/aktualizuje kanał #mody-optymalizacja i wysyła embedy modów.
 */
async function setupModsChannel(guild) {
  const category = guild.channels.cache.find(
    (c) => c.name === config.category.main && c.type === ChannelType.GuildCategory
  );
  let modsChannel = guild.channels.cache.find(
    (c) => c.name === config.channel.mods && c.parentId === category?.id
  );
  if (!modsChannel) {
    modsChannel = await guild.channels.create({
      name: config.channel.mods,
      type: ChannelType.GuildText,
      parent: category?.id,
      topic: 'Sprawdzone mody optymalizacyjne (klienckie) do FiveM - tylko pliki do folderu gry, nie skrypty serwerowe.',
    });
  }

  await verifyAllMods();
  await postModsList(modsChannel, guild);
  return modsChannel;
}

/**
 * Wysyła (lub odświeża) listę modów na kanale.
 * Zawsze czyści dotychczasowe wiadomości bota i wysyła świeże - dzięki temu
 * aktualizacja bazy (plik config.js) od razu widoczna jest na Discordzie.
 */
async function postModsList(channel, guild) {
  // Usuń stare wiadomości bota na kanale (maks. 100 ostatnich)
  try {
    const messages = await channel.messages.fetch({ limit: 100 });
    const botMessages = messages.filter((m) => m.author.id === guild.client.user.id);
    if (botMessages.size) await channel.bulkDelete(botMessages, true).catch(() => {});
  } catch (_) {
    /* brak uprawnień - pomijamy */
  }

  const header = new EmbedBuilder()
    .setTitle('⚡ Mody optymalizacyjne — FiveM (klient)')
    .setDescription(
      [
        'Poniżej **zweryfikowane** mody klienckie - pliki wgrywane do folderu gry',
        '(`mods` / `citizen`), **nie** skrypty serwerowe.',
        '',
        '🔗 Każdy link prowadzi do **strony moda** (stabilny URL, nie wygasa po aktualizacjach),',
        'gdzie pobierzesz aktualną wersję z bezpiecznego źródła.',
        `🕒 Ostatnia weryfikacja linków: <t:${Math.floor(Date.now() / 1000)}:R>`,
      ].join('\n')
    )
    .setColor(0x5865f2)
    .setTimestamp();

  await channel.send({ embeds: [header] });

  for (const mod of config.optimizationMods) {
    const health = linkHealth.get(mod.id) || { ok: true, status: 0, sizeMB: 0 };
    const statusEmoji = health.ok ? '✅' : '⚠️';

    const embed = new EmbedBuilder()
      .setTitle(`${statusEmoji} ${mod.name}`)
      .setDescription(mod.description)
      .addFields(
        { name: '📈 Wpływ na FPS', value: mod.fpsImpact, inline: true },
        { name: '🏷️ Typ', value: 'Klient (folder gry)', inline: true },
        { name: '👤 Autor', value: mod.author || '—', inline: true },
        { name: '🔗 Pobierz ze strony', value: `[Otwórz stronę moda](${mod.pageUrl || mod.url})` }
      )
      .setThumbnail(mod.thumbnail)
      .setColor(health.ok ? 0x57f287 : 0xfee75c)
      .setFooter({ text: health.ok ? 'Link zweryfikowany przez bota' : `⚠️ Link nieosiągalny (HTTP ${health.status}) - zgłoś do administracji` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel('Pobierz ze strony')
        .setStyle(ButtonStyle.Link)
        .setURL(mod.pageUrl || mod.url)
    );

    await channel.send({ embeds: [embed], components: [row] });
  }
}

/**
 * Odświeża listę modów na wszystkich serwerach + ponowna weryfikacja linków.
 * Wywoływane cyklicznie z index.js.
 */
async function refreshModsOnAllGuilds(client) {
  await verifyAllMods();
  for (const guild of client.guilds.cache.values()) {
    try {
      const category = guild.channels.cache.find(
        (c) => c.name === config.category.main && c.type === ChannelType.GuildCategory
      );
      const modsChannel = guild.channels.cache.find(
        (c) => c.name === config.channel.mods && c.parentId === category?.id
      );
      if (modsChannel) await postModsList(modsChannel, guild);
    } catch (err) {
      console.error(`Błąd odświeżania modów na ${guild.name}:`, err.message);
    }
  }
}

module.exports = { setupModsChannel, postModsList, verifyAllMods, refreshModsOnAllGuilds };
