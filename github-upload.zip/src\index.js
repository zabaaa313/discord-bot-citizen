const { Client, GatewayIntentBits, Partials, Collection, Events } = require('discord.js');
const config = require('./config');
const { registerCommands } = require('./deploy-commands');
const { startHttpServer } = require('./http-server');
const { onReady } = require('./events/ready');
const { onInteractionCreate } = require('./events/interactionCreate');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
  ],
  partials: [Partials.Channel, Partials.Message],
});

// Rejestr komend interakcji: nazwa -> moduł { execute(interaction) }
client.commands = new Collection();

(async () => {
  await registerCommands(client);

  client.once(Events.ClientReady, () => onReady(client));
  client.on(Events.InteractionCreate, (interaction) => onInteractionCreate(client, interaction));
  client.on(Events.GuildCreate, async (guild) => {
    const { setupGuild } = require('./setup');
    await setupGuild(guild).catch((e) => console.error('Błąd konfiguracji serwera:', e));
  });

  process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));

  await client.login(config.token);
  startHttpServer();

  // Cykliczna weryfikacja linków modów + odświeżanie kanałów #mody-optymalizacja
  const { refreshModsOnAllGuilds } = require('./mods-channel');
  setInterval(() => {
    refreshModsOnAllGuilds(client).catch((e) =>
      console.error('Błąd odświeżania modów:', e.message)
    );
  }, config.modsCheckIntervalMs).unref();
})();
