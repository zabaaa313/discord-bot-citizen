const { ActivityType } = require('discord.js');
const config = require('../config');
const { setupGuild } = require('../setup');

module.exports.onReady = async function onReady(client) {
  console.log(`🤖 Zalogowano jako ${client.user.tag}`);
  client.user.setActivity('Kreator Citizenów FiveM', { type: ActivityType.Watching });

  // Auto-konfiguracja dla serwerów, na których bot już jest
  for (const guild of client.guilds.cache.values()) {
    try {
      await setupGuild(guild);
    } catch (err) {
      console.error(`❌ Konfiguracja serwera ${guild.name} nieudana:`, err.message);
    }
  }
};
