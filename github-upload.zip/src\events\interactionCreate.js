const { Events } = require('discord.js');
const router = require('../commands/interactionCreate');

module.exports.onInteractionCreate = router.onInteractionCreate;
