require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  httpPort: parseInt(process.env.HTTP_PORT || '3000', 10),
  publicUrl: process.env.PUBLIC_URL || `http://localhost:${process.env.HTTP_PORT || 3000}`,

  // === Nazwy elementów tworzonych na serwerze Discord ===
  role: {
    creator: 'Creator',
    building: 'Tworzenie citizena', // tymczasowa rola nadawana podczas tworzenia
  },
  category: {
    main: 'FIVEM CITIZEN CREATOR',
    tickets: 'TWOJE CITIZENY',
  },
  channel: {
    main: 'stworz-citizena',
    downloads: 'pobrane-paczki',
    mods: 'mody-optymalizacja',
  },

  // === Limity bezpieczeństwa ===
  limits: {
    maxSessionsPerUser: 1,          // ile równoległych sesji kreatora na użytkownika
    sessionTtlMs: 2 * 60 * 60 * 1000, // po 2h bezczynności sesja wygasa
    downloadTtlMs: 24 * 60 * 60 * 1000, // paczki ZIP dostępne 24h
    maxDownloadBytes: 200 * 1024 * 1024, // twardy limit rozmiaru pojedynczego pobrania (200 MB)
  },

  // Jak często bot ponownie weryfikuje linki w bazie modów (domyślnie 6h)
  modsCheckIntervalMs: 6 * 60 * 60 * 1000,

  /**
   * === KROKI KREATORA ===
   *
   * TO JEDYNE MIEJSCE, KTÓRE MUSISZ EDYTOWAĆ, ABY DODAWAĆ/USUWAĆ OPCJE.
   *
   *  - id       : unikalny identyfikator kroku
   *  - name     : wyświetlana nazwa modyfikacji
   *  - image    : URL zdjęcia poglądowego (efekt wizualny w grze).
   *               HOSTUJ GRAFIKI SAM (np. imgur / własny hosting) - Discord wymaga
   *               działających, publicznych URL-i. Podmień poniższe placeholdery!
   *  - fileUrl  : URL pliku modyfikacji do pobrania (plik resource / .ymt / .ytd itp.)
   *  - fileName : pod jaka nazwa plik trafia do paczki
   *  - target   : ścieżka wewnątrz paczki citizen (struktura FiveM:
   *               np. "citizen/common/data" lub osobny resource w "resources/")
   *  - mode     : jak dołączyć plik:
   *                  'file'    - pobierz i wstaw pod fileName
   *                  'resource'- pobierz (zip z modem) i rozpakuj do target
   *  - extract  : (tylko mode:'resource') podfolder wewnątrz zipa moda,
   *               "true" = rozpakuj cały zip jako resource, false/null = wszystko
   *  - description : opis efektu widoczny w embedzie
   */
  steps: [
    {
      id: 'sky',
      name: 'Niebo',
      description: 'Zmienia wygląd nieba - bardziej realistyczne, ciemniejsze nocne niebo.',
      image: 'https://i.imgur.com/ZMIJFjr.jpeg', // PODMIEŃ na własną grafikę
      mode: 'file',
      fileUrl: 'https://example.com/mods/timecycle_mod_1.xml', // PODMIEŃ na własny link
      fileName: 'timecycle_mod_1.xml',
      target: 'citizen/common/data/timecycle',
    },
    {
      id: 'shadows',
      name: 'Usunięcie cieni',
      description: 'Wyłącza cienie dynamiczne - większy FPS na słabszych PC.',
      image: 'https://i.imgur.com/SHADOW1.jpeg', // PODMIEŃ
      mode: 'file',
      fileUrl: 'https://example.com/mods/shaders.xml',
      fileName: 'shaders.xml',
      target: 'citizen/common/data',
    },
    {
      id: 'water',
      name: 'Woda',
      description: 'Czystsza, bardziej przezroczysta woda.',
      image: 'https://i.imgur.com/WATER1.jpeg', // PODMIEŃ
      mode: 'file',
      fileUrl: 'https://example.com/mods/water.xml',
      fileName: 'water.xml',
      target: 'citizen/common/data/levels/gta5',
    },
    {
      id: 'blood',
      name: 'Krew',
      description: 'Realistyczny efekt krwi.',
      image: 'https://i.imgur.com/BLOOD1.jpeg', // PODMIEŃ
      mode: 'file',
      fileUrl: 'https://example.com/mods/bloodfx.dat',
      fileName: 'bloodfx.dat',
      target: 'citizen/common/data/effects/pc',
    },
  ],

  /**
   * === BAZA MODÓW OPTYMALIZACYJNYCH (kanał #mody-optymalizacja) ===
   *
   * WAŻNE — jak to działa naprawdę:
   * Boty Discord NIE przeszukują „całego internetu" i nie oceniają bezpieczeństwa
   * plików. Niezawodne podejście to KURATOROWANA BAZA (poniżej) + AUTOMATYCZNA
   * WERYFIKACJA LINKÓW: co modsCheckIntervalMs bot sprawdza każdy URL (czy
   * odpowiada 200/redirect i ile waży) i oznacza martwe linki na kanale.
   *
   * Źródła legitnych linków, które możesz tu wkleić po ręcznej weryfikacji:
   *  - GitHub (releases własnych/opensourcowych pakietów optymalizacyjnych),
   *  - gta5-mods.com (strona z modami do GTA V; każdy mod ma stabilny URL,
   *    np. https://www.gta5-mods.com/misc/nazwa-moda — bot linkuje do STRONY
   *    moda, a nie bezpośrednio do pliku, co jest zgodne z ich regulaminem
   *    i sprawia, że link nie wygasa po aktualizacji moda),
   *  - forum.cfx.re (ogłoszenia autorów modów FiveM).
   *
   * Nie linkuj bezpośrednio do plików z hostingów z ograniczeniem hotlinków —
   * takie linki szybko wygasają.
   */
  optimizationMods: [
    {
      id: 'fps-boost-pack',
      name: 'FPS Boost Pack (tymczasowo przykładowy wpis)',
      description:
        'Zestaw poprawek timecycle i draw distance zwiększający FPS na średnich PC.',
      fpsImpact: '+10-25 FPS na średnich konfiguracjach',
      url: 'https://www.gta5-mods.com/misc/fps-boost-pack', // PODMIEŃ na zweryfikowany link
      pageUrl: 'https://www.gta5-mods.com/misc/fps-boost-pack',
      thumbnail: 'https://i.imgur.com/ZMIJFjr.jpeg', // PODMIEŃ
      tags: ['fps', 'timecycle'],
      author: '—',
    },
    {
      id: 'no-shadows',
      name: 'No Dynamic Shadows (tymczasowo przykładowy wpis)',
      description: 'Wyłącza cienie dynamiczne - duży zysk FPS na słabszych kartach.',
      fpsImpact: '+15-30 FPS na GPU klasy GTX 1050',
      url: 'https://www.gta5-mods.com/misc/no-dynamic-shadows', // PODMIEŃ
      pageUrl: 'https://www.gta5-mods.com/misc/no-dynamic-shadows',
      thumbnail: 'https://i.imgur.com/SHADOW1.jpeg', // PODMIEŃ
      tags: ['fps', 'shadows'],
      author: '—',
    },
  ],

  /**
   * === BAZA BRONI I SKINÓW (Kreator skinów do broni) ===
   *
   * Bronie GTA V/FiveM dostępne w select menu. Dla każdej broni lista skinów.
   * Skin: mode 'resource' -> bot pobiera ZIP z modem i rozpakowuje do target
   * (typowa struktura moda replace: folder z plikami .ytd/.ydr).
   * Skin: mode 'file' -> pojedynczy plik .ytd/.ydr pod ścieżką target.
   *
   * Struktura docelowa: mody replace tekstur broni wgrywa się przez OpenIV
   * do citizen/common.rpf/data/... - bot buduje analogiczne drzewo folderów
   * w paczce ZIP.
   */
  weapons: [
    {
      id: 'pistol',
      name: 'Pistol',
      skins: [
        {
          id: 'pistol-blackops',
          name: 'Black Ops',
          description: 'Czarny matowy skin z zielonymi akcentami.',
          image: 'https://i.imgur.com/SKIN1.jpeg', // PODMIEŃ
          mode: 'file',
          fileUrl: 'https://example.com/skins/w_pistol_blackops.ytd', // PODMIEŃ
          fileName: 'w_pi_pistol.ytd',
          target: 'citizen/common.rpf/data/props/weapons',
        },
        {
          id: 'pistol-desert',
          name: 'Desert Tan',
          description: 'Pustynny kamuflaż.',
          image: 'https://i.imgur.com/SKIN2.jpeg', // PODMIEŃ
          mode: 'file',
          fileUrl: 'https://example.com/skins/w_pistol_desert.ytd', // PODMIEŃ
          fileName: 'w_pi_pistol.ytd',
          target: 'citizen/common.rpf/data/props/weapons',
        },
      ],
    },
    {
      id: 'heavypistol',
      name: 'Heavy Pistol',
      skins: [
        {
          id: 'heavypistol-chrome',
          name: 'Chrome',
          description: 'Chromowany połysk.',
          image: 'https://i.imgur.com/SKIN3.jpeg', // PODMIEŃ
          mode: 'file',
          fileUrl: 'https://example.com/skins/w_heavypistol_chrome.ytd', // PODMIEŃ
          fileName: 'w_pi_histol.ytd',
          target: 'citizen/common.rpf/data/props/weapons',
        },
      ],
    },
    {
      id: 'appistol',
      name: 'AP Pistol',
      skins: [
        {
          id: 'appistol-carbon',
          name: 'Carbon Fiber',
          description: 'Węglowy wzór.',
          image: 'https://i.imgur.com/SKIN4.jpeg', // PODMIEŃ
          mode: 'file',
          fileUrl: 'https://example.com/skins/w_appistol_carbon.ytd', // PODMIEŃ
          fileName: 'w_pi_ap_pistol.ytd',
          target: 'citizen/common.rpf/data/props/weapons',
        },
      ],
    },
    {
      id: 'carbine',
      name: 'Carbine Rifle',
      skins: [
        {
          id: 'carbine-woodland',
          name: 'Woodland',
          description: 'Leśny kamuflaż.',
          image: 'https://i.imgur.com/SKIN5.jpeg', // PODMIEŃ
          mode: 'file',
          fileUrl: 'https://example.com/skins/w_carbine_woodland.ytd', // PODMIEŃ
          fileName: 'w_ar_carbine.ytd',
          target: 'citizen/common.rpf/data/props/weapons',
        },
      ],
    },
    {
      id: 'ak47',
      name: 'AK-47 (Assault Rifle)',
      skins: [
        {
          id: 'ak47-redline',
          name: 'Redline',
          description: 'Czerwone linie na czerni.',
          image: 'https://i.imgur.com/SKIN6.jpeg', // PODMIEŃ
          mode: 'file',
          fileUrl: 'https://example.com/skins/w_ak47_redline.ytd', // PODMIEŃ
          fileName: 'w_ar_assaultrifle.ytd',
          target: 'citizen/common.rpf/data/props/weapons',
        },
      ],
    },
  ],
};
