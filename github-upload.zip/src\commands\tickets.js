const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  OverwriteType,
} = require('discord.js');
const config = require('../config');
const { sendPanel } = require('../setup');
const { createSession, deleteSession, getSessionByChannel, getSessionByUser } = require('../sessions');

/**
 * Handler przycisku "Zacznij tworzyć citizena":
 * tworzy prywatny kanał w stylu ticketa i startuje kreator.
 */
module.exports.handleCreateCitizen = async function handleCreateCitizen(interaction) {
  const { guild, member, user } = interaction;

  // Limit równoległych sesji
  const existing = getSessionByUser(user.id, guild.id);
  if (existing) {
    return interaction.reply({
      content: `❌ Masz już otwartą sesję tworzenia: <#${existing.channelId}>. Zakończ ją lub użyj /zamknij.`,
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  const buildingRole = guild.roles.cache.find((r) => r.name === config.role.building);
  const everyone = guild.roles.everyone;

  const channel = await guild.channels.create({
    name: `citizen-${user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 90),
    type: ChannelType.GuildText,
    parent: guild.channels.cache.find(
      (c) => c.name === config.category.tickets && c.type === ChannelType.GuildCategory
    )?.id,
    permissionOverwrites: [
      { id: everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: user.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.AttachFiles,
        ],
        type: OverwriteType.Member,
      },
      {
        id: interaction.client.user.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.AttachFiles,
          PermissionFlagsBits.ManageMessages,
        ],
        type: OverwriteType.Member,
      },
      ...(buildingRole
        ? [{ id: buildingRole.id, deny: [PermissionFlagsBits.ViewChannel] }]
        : []),
    ],
  });

  // Nadaj rolę tymczasową
  if (buildingRole) {
    await member.roles.add(buildingRole).catch(() => {});
  }

  const session = createSession({
    userId: user.id,
    guildId: guild.id,
    channelId: channel.id,
  });

  await interaction.editReply({
    content: `✅ Twój prywatny kanał: <#${channel.id}>`,
  });

  // Powitanie + wybór trybu (citizen lub skiny broni)
  const embed = new EmbedBuilder()
    .setTitle(`👋 Cześć ${user.username}!`)
    .setDescription(
      [
        'To Twój **prywatny kanał kreatora**.',
        '',
        'Wybierz co chcesz stworzyć:',
        '🛠️ **Citizen** — modyfikacje wizualne (niebo, cienie, woda, krew...),',
        '🔫 **Skiny broni** — personalizacja wyglądu broni (.ytd/.ydr).',
        '',
        '**Możesz w każdej chwili przerwać** — użyj `/zamknij`.',
      ].join('\n')
    )
    .setColor(0x57f287)
    .setTimestamp();

  const modeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('create_citizen')
      .setLabel('Citizen (mody wizualne)')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🛠️'),
    new ButtonBuilder()
      .setCustomId('create_weapon_skins')
      .setLabel('Skiny broni')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('🔫')
  );

  await channel.send({ content: `<@${user.id}>`, embeds: [embed], components: [modeRow] });
};

/**
 * Handler przycisku "Skiny broni": startuje kreator skinów na tym samym kanale.
 */
module.exports.handleCreateWeaponSkins = async function handleCreateWeaponSkins(interaction) {
  const session = getSessionByChannel(interaction.channel.id);
  if (!session || interaction.user.id !== session.userId) {
    return interaction.reply({ content: '❌ To nie Twoja sesja.', ephemeral: true });
  }

  await interaction.deferReply();
  const { sendWeaponSelect } = require('./weapon-skins');
  await sendWeaponSelect(interaction.channel, session);
  await interaction.deleteReply().catch(() => {});
};

module.exports.handleCloseSession = async function handleCloseSession(interaction, reason) {
  const session = getSessionByChannel(interaction.channel.id);
  if (!session) {
    return interaction.reply({ content: '❌ To nie jest kanał sesji kreatora.', ephemeral: true });
  }
  await interaction.reply({ content: '🔒 Zamykanie sesji...' });
  await cleanupSession(interaction.client, session, reason || 'Zamknięto przez użytkownika');
};

/**
 * Sprzątanie po sesji: usuwa kanał, zdejmuję rolę tymczasową, usuwa sesję z pamięci.
 */
module.exports.cleanupSession = async function cleanupSession(client, session, reason) {
  const guild = client.guilds.cache.get(session.guildId);
  if (!guild) return deleteSession(session.channelId);

  const buildingRole = guild.roles.cache.find((r) => r.name === config.role.building);
  if (buildingRole) {
    const member = await guild.members.fetch(session.userId).catch(() => null);
    if (member) await member.roles.remove(buildingRole).catch(() => {});
  }

  const channel = guild.channels.cache.get(session.channelId);
  if (channel) {
    await channel.send({ content: `🔒 Sesja zakończona: ${reason}` }).catch(() => {});
    setTimeout(() => channel.delete('Koniec sesji kreatora citizena').catch(() => {}), 3000);
  }

  deleteSession(session.channelId);
};
